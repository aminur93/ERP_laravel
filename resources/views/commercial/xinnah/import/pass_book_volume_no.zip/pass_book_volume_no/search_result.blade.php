<div class="row">
  <div class="entry_result_section">
      <div class="panel panel-success">
        <div class="panel-body">
          <div class="table_result">
              <div class="col-sm-offset-2 col-sm-8">
                  <div class="table-responsive">
                      <table class="table table-bordered">
                        <thead>
                            <tr class="success">
                                <th>File No.</th>
                                <th>L/C No.</th>
                                <th>Supplier</th>
                                <th>Value</th>
                                <th width="12%">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        	@foreach($getResult as $data)
                            <tr>
                              <th>{{$data->file->file_no}}</th>
                              <th>{{$data->lc_no}}</th>
                              <th>{{$data->supplier->sup_name}}</th>
                              <th>{{$data->value}}</th>
                              <th>
                                <a id="actionBtn" class="btn btn-info btn-sm" onclick="chooseFileData({{$data->cm_imp_data_entry_id}}, {{$data->cm_btb_id}})">Select</a>
                              </th>
                            </tr>
                          @endforeach
                        </tbody>
                        
                      </table>
                  </div>
              </div>
          </div>
        </div>
      </div>
  </div>
</div>